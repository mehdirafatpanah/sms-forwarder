package com.shopvpn.smsforwarder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.shopvpn.smsforwarder.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS
    )

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            Toast.makeText(this, "مجوزها با موفقیت داده شد ✅", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "بدون این مجوزها اپ نمی‌تواند پیامک بخواند ❌", Toast.LENGTH_LONG).show()
        }
        updatePermissionStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // بارگذاری تنظیمات ذخیره‌شده
        binding.editWebhookUrl.setText(Prefs.getWebhookUrl(this))
        binding.editToken.setText(Prefs.getToken(this))

        binding.btnRequestPermissions.setOnClickListener { requestSmsPermissions() }
        binding.btnBatteryOptimization.setOnClickListener { requestIgnoreBatteryOptimizations() }

        binding.btnSave.setOnClickListener {
            Prefs.setWebhookUrl(this, binding.editWebhookUrl.text.toString().trim())
            Prefs.setToken(this, binding.editToken.text.toString().trim())
            Toast.makeText(this, "تنظیمات ذخیره شد ✅", Toast.LENGTH_SHORT).show()
        }

        binding.btnTestConnection.setOnClickListener { sendTestPing() }
        binding.btnRefreshLog.setOnClickListener { refreshLog() }

        binding.btnAddTemplate.setOnClickListener { addTemplate() }
        binding.btnBulkAddTemplates.setOnClickListener { bulkAddTemplates() }
        binding.btnTestTemplate.setOnClickListener { testTemplateMatch() }
        binding.btnRestoreDefaultTemplates.setOnClickListener { restoreDefaultTemplates() }

        // در اولین اجرای برنامه، قالب‌های پیش‌فرض بانک‌ها را به‌صورت خودکار اضافه می‌کند.
        Prefs.ensureDefaultTemplatesLoaded(this)

        updatePermissionStatus()
        updateBatteryStatus()
        refreshLog()
        refreshTemplatesList()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
        updateBatteryStatus()
        refreshLog()
    }

    private fun hasAllPermissions(): Boolean =
        requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestSmsPermissions() {
        if (!hasAllPermissions()) {
            permissionLauncher.launch(requiredPermissions)
        } else {
            Toast.makeText(this, "مجوزها از قبل فعال هستند ✅", Toast.LENGTH_SHORT).show()
        }
    }

    /** چیپ وضعیت مجوز پیامک را متناسب با وضعیت فعلی (سبز/قرمز) رنگ‌آمیزی می‌کند. */
    private fun updatePermissionStatus() {
        val granted = hasAllPermissions()
        binding.textPermissionStatus.text = if (granted) "مجوز پیامک: فعال" else "مجوز پیامک: غیرفعال"

        val textColor = ContextCompat.getColor(this, if (granted) R.color.status_success else R.color.status_danger)
        binding.textPermissionStatus.setTextColor(textColor)
        binding.iconPermissionChip.setColorFilter(textColor)
        binding.iconPermissionChip.setImageResource(if (granted) R.drawable.ic_check else R.drawable.ic_close)
        binding.chipPermission.setBackgroundResource(
            if (granted) R.drawable.bg_chip_success else R.drawable.bg_chip_danger
        )
    }

    /** چیپ وضعیت معافیت از بهینه‌سازی باتری را متناسب با وضعیت فعلی رنگ‌آمیزی می‌کند. */
    private fun updateBatteryStatus() {
        val exempt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        } else {
            true
        }
        binding.textBatteryStatus.text = if (exempt) "باتری: بهینه" else "باتری: نیاز به تنظیم"

        val textColor = ContextCompat.getColor(this, if (exempt) R.color.status_success else R.color.status_warning)
        binding.textBatteryStatus.setTextColor(textColor)
        binding.iconBatteryChip.setColorFilter(textColor)
        binding.chipBattery.setBackgroundResource(
            if (exempt) R.drawable.bg_chip_success else R.drawable.bg_chip_warning
        )
    }

    /**
     * اندروید برای صرفه‌جویی باتری ممکن است اپ‌های در پس‌زمینه را محدود کند.
     * از کاربر می‌خواهیم این اپ را از Doze/App Standby معاف کند تا دریافت پیامک قطع نشود.
     */
    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "لطفاً دستی از تنظیمات گوشی، بهینه‌سازی باتری این اپ را خاموش کن", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "این اپ از قبل از بهینه‌سازی باتری معاف است ✅", Toast.LENGTH_SHORT).show()
        }
        updateBatteryStatus()
    }

    /** یک پیام آزمایشی به وب‌هوک می‌فرستد تا از صحت آدرس/توکن مطمئن شویم. */
    private fun sendTestPing() {
        val url = binding.editWebhookUrl.text.toString().trim()
        val token = binding.editToken.text.toString().trim()
        if (url.isBlank() || token.isBlank()) {
            Toast.makeText(this, "اول آدرس و توکن را وارد و ذخیره کن", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.setWebhookUrl(this, url)
        Prefs.setToken(this, token)

        val inputData = Data.Builder()
            .putString(ForwardWorker.KEY_SENDER, "TEST")
            .putString(ForwardWorker.KEY_BODY, "این یک پیام آزمایشی از اپ فورواردر است.")
            .putLong(ForwardWorker.KEY_TIMESTAMP, System.currentTimeMillis())
            .build()

        val request = OneTimeWorkRequestBuilder<ForwardWorker>()
            .setInputData(inputData)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(this).enqueue(request)
        Toast.makeText(this, "پیام تست ارسال شد؛ نتیجه را در بخش لاگ پایین صفحه ببین", Toast.LENGTH_LONG).show()

        binding.root.postDelayed({ refreshLog() }, 3000)
    }

    private fun refreshLog() {
        binding.textLog.text = LogStore.getAllAsText(this)
    }

    /** چند قالب که با خط "---" از هم جدا شده‌اند را یکجا اضافه می‌کند. */
    private fun bulkAddTemplates() {
        val raw = binding.editBulkTemplates.text.toString()
        if (raw.isBlank()) {
            Toast.makeText(this, "چیزی برای افزودن نیست", Toast.LENGTH_SHORT).show()
            return
        }

        val parts = raw.split(Regex("(?m)^\\s*---\\s*$"))
            .map { it.trim('\n', '\r', ' ') }
            .filter { it.isNotBlank() }

        if (parts.isEmpty()) {
            Toast.makeText(this, "هیچ قالب معتبری پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }

        val existing = Prefs.getTemplates(this).toMutableList()
        existing.addAll(parts)
        Prefs.setTemplates(this, existing)
        binding.editBulkTemplates.setText("")
        refreshTemplatesList()
        Toast.makeText(this, "${parts.size} قالب اضافه شد ✅", Toast.LENGTH_LONG).show()
    }

    /** قالب‌های پیش‌فرض بانک‌هایی که کاربر حذف کرده (یا هنوز اضافه نشده‌اند) را دوباره اضافه می‌کند. */
    private fun restoreDefaultTemplates() {
        val added = Prefs.restoreDefaultTemplates(this)
        refreshTemplatesList()
        Toast.makeText(
            this,
            if (added > 0) "$added قالب پیش‌فرض اضافه شد ✅" else "همه قالب‌های پیش‌فرض از قبل موجودند",
            Toast.LENGTH_SHORT
        ).show()
    }

    /** یک قالب جدید از EditText می‌گیرد و ذخیره می‌کند. */
    private fun addTemplate() {
        val text = binding.editNewTemplate.text.toString().trim()
        if (text.isBlank()) {
            Toast.makeText(this, "متن قالب خالیه", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.addTemplate(this, text)
        binding.editNewTemplate.setText("")
        refreshTemplatesList()
        Toast.makeText(this, "قالب اضافه شد ✅", Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    /** لیست قالب‌های ذخیره‌شده را به‌صورت کارت‌های شماره‌دار با دکمه حذف آیکونی نمایش می‌دهد. */
    private fun refreshTemplatesList() {
        val container = binding.templatesContainer
        container.removeAllViews()
        val templates = Prefs.getTemplates(this)

        if (templates.isEmpty()) {
            val empty = TextView(this).apply {
                text = "هنوز قالبی ثبت نشده. از بخش «قالب‌های پیامک بانک» بالا یا افزودن دستی استفاده کن."
                textSize = 12.5f
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_secondary))
                setPadding(0, dp(4), 0, dp(4))
            }
            container.addView(empty)
            return
        }

        templates.forEachIndexed { index, template ->
            val lines = template.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val title = lines.firstOrNull() ?: template
            val subtitle = if (lines.size > 1) lines.drop(1).joinToString(" · ") else "قالب سفارشی"

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_template_row)
                setPadding(dp(12), dp(10), dp(10), dp(10))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(10) }
            }

            val badge = FrameLayout(this).apply {
                setBackgroundResource(R.drawable.bg_badge_circle)
                layoutParams = LinearLayout.LayoutParams(dp(28), dp(28))
            }
            val badgeText = TextView(this).apply {
                text = (index + 1).toString()
                textSize = 11.5f
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.badge_text))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
                ).apply { gravity = Gravity.CENTER }
            }
            badge.addView(badgeText)

            val textColumn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                ).apply { marginStart = dp(10); marginEnd = dp(6) }
            }
            val titleView = TextView(this).apply {
                text = title
                textSize = 13f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
            val subtitleView = TextView(this).apply {
                text = subtitle
                textSize = 11.5f
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_secondary))
                setPadding(0, dp(2), 0, 0)
            }
            textColumn.addView(titleView)
            textColumn.addView(subtitleView)

            val deleteBtn = ImageButton(this).apply {
                setImageResource(R.drawable.ic_delete)
                setColorFilter(ContextCompat.getColor(this@MainActivity, R.color.status_danger))
                background = android.util.TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
                    ContextCompat.getDrawable(this@MainActivity, tv.resourceId)
                }
                scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(6), dp(6), dp(6), dp(6))
                layoutParams = LinearLayout.LayoutParams(dp(34), dp(34))
                contentDescription = "حذف قالب"
                setOnClickListener {
                    Prefs.removeTemplate(this@MainActivity, index)
                    refreshTemplatesList()
                }
            }

            row.addView(badge)
            row.addView(textColumn)
            row.addView(deleteBtn)
            container.addView(row)
        }
    }

    /** متن تستی وارد‌شده را با قالب‌های ذخیره‌شده مقایسه می‌کند و نتیجه را نمایش می‌دهد. */
    private fun testTemplateMatch() {
        val sample = binding.editTestSms.text.toString()
        if (sample.isBlank()) {
            Toast.makeText(this, "یه نمونه پیامک برای تست وارد کن", Toast.LENGTH_SHORT).show()
            return
        }

        val templates = Prefs.getTemplates(this)
        if (templates.isEmpty()) {
            setTestResult("⚠️ هنوز هیچ قالبی ثبت نشده.", R.color.status_warning)
            return
        }

        val match = TemplateMatcher.findMatch(sample, templates)
        if (match == null) {
            setTestResult("❌ با هیچ‌کدام از قالب‌ها مطابقت نداشت.", R.color.status_danger)
        } else {
            val groupsText = if (match.groups.isEmpty()) {
                "(بدون فیلد متغیر)"
            } else {
                match.groups.entries.joinToString(" | ") { "${it.key}=${it.value}" }
            }
            setTestResult("✅ با قالب شماره ${match.templateIndex + 1} مطابقت داشت.\n$groupsText", R.color.status_success)
        }
    }

    private fun setTestResult(text: String, colorRes: Int) {
        binding.textTestResult.text = text
        binding.textTestResult.setTextColor(ContextCompat.getColor(this, colorRes))
    }
}
