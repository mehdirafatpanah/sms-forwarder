package com.shopvpn.smsforwarder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.shopvpn.smsforwarder.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS
    )

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            Toast.makeText(this, "مجوزها با موفقیت داده شد ✅", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "بدون این مجوزها اپ نمی‌تواند پیامک بخواند ❌", Toast.LENGTH_LONG).show()
        }
        updatePermissionStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // بارگذاری تنظیمات ذخیره‌شده
        binding.editWebhookUrl.setText(Prefs.getWebhookUrl(this))
        binding.editToken.setText(Prefs.getToken(this))

        binding.btnRequestPermissions.setOnClickListener { requestSmsPermissions() }
        binding.btnBatteryOptimization.setOnClickListener { requestIgnoreBatteryOptimizations() }

        binding.btnSave.setOnClickListener {
            Prefs.setWebhookUrl(this, binding.editWebhookUrl.text.toString().trim())
            Prefs.setToken(this, binding.editToken.text.toString().trim())
            Toast.makeText(this, "تنظیمات ذخیره شد ✅", Toast.LENGTH_SHORT).show()
        }

        binding.btnTestConnection.setOnClickListener { sendTestPing() }
        binding.btnRefreshLog.setOnClickListener { refreshLog() }

        binding.btnAddTemplate.setOnClickListener { addTemplate() }
        binding.btnBulkAddTemplates.setOnClickListener { bulkAddTemplates() }
        binding.btnTestTemplate.setOnClickListener { testTemplateMatch() }

        updatePermissionStatus()
        refreshLog()
        refreshTemplatesList()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
        refreshLog()
    }

    private fun hasAllPermissions(): Boolean =
        requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestSmsPermissions() {
        if (!hasAllPermissions()) {
            permissionLauncher.launch(requiredPermissions)
        } else {
            Toast.makeText(this, "مجوزها از قبل فعال هستند ✅", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePermissionStatus() {
        binding.textPermissionStatus.text = if (hasAllPermissions()) {
            "وضعیت مجوز پیامک: ✅ فعال"
        } else {
            "وضعیت مجوز پیامک: ❌ غیرفعال (روی دکمه بالا بزن)"
        }
    }

    /**
     * اندروید برای صرفه‌جویی باتری ممکن است اپ‌های در پس‌زمینه را محدود کند.
     * از کاربر می‌خواهیم این اپ را از Doze/App Standby معاف کند تا دریافت پیامک قطع نشود.
     */
    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "لطفاً دستی از تنظیمات گوشی، بهینه‌سازی باتری این اپ را خاموش کن", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "این اپ از قبل از بهینه‌سازی باتری معاف است ✅", Toast.LENGTH_SHORT).show()
        }
    }

    /** یک پیام آزمایشی به وب‌هوک می‌فرستد تا از صحت آدرس/توکن مطمئن شویم. */
    private fun sendTestPing() {
        val url = binding.editWebhookUrl.text.toString().trim()
        val token = binding.editToken.text.toString().trim()
        if (url.isBlank() || token.isBlank()) {
            Toast.makeText(this, "اول آدرس و توکن را وارد و ذخیره کن", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.setWebhookUrl(this, url)
        Prefs.setToken(this, token)

        val inputData = Data.Builder()
            .putString(ForwardWorker.KEY_SENDER, "TEST")
            .putString(ForwardWorker.KEY_BODY, "این یک پیام آزمایشی از اپ فورواردر است.")
            .putLong(ForwardWorker.KEY_TIMESTAMP, System.currentTimeMillis())
            .build()

        val request = OneTimeWorkRequestBuilder<ForwardWorker>()
            .setInputData(inputData)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(this).enqueue(request)
        Toast.makeText(this, "پیام تست ارسال شد؛ نتیجه را در بخش لاگ پایین صفحه ببین", Toast.LENGTH_LONG).show()

        binding.root.postDelayed({ refreshLog() }, 3000)
    }

    private fun refreshLog() {
        binding.textLog.text = LogStore.getAllAsText(this)
    }

    /** چند قالب که با خط "---" از هم جدا شده‌اند را یکجا اضافه می‌کند. */
    private fun bulkAddTemplates() {
        val raw = binding.editBulkTemplates.text.toString()
        if (raw.isBlank()) {
            Toast.makeText(this, "چیزی برای افزودن نیست", Toast.LENGTH_SHORT).show()
            return
        }

        val parts = raw.split(Regex("(?m)^\\s*---\\s*$"))
            .map { it.trim('\n', '\r', ' ') }
            .filter { it.isNotBlank() }

        if (parts.isEmpty()) {
            Toast.makeText(this, "هیچ قالب معتبری پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }

        val existing = Prefs.getTemplates(this).toMutableList()
        existing.addAll(parts)
        Prefs.setTemplates(this, existing)
        binding.editBulkTemplates.setText("")
        refreshTemplatesList()
        Toast.makeText(this, "${parts.size} قالب اضافه شد ✅", Toast.LENGTH_LONG).show()
    }

    /** یک قالب جدید از EditText می‌گیرد و ذخیره می‌کند. */
    private fun addTemplate() {
        val text = binding.editNewTemplate.text.toString().trim()
        if (text.isBlank()) {
            Toast.makeText(this, "متن قالب خالیه", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.addTemplate(this, text)
        binding.editNewTemplate.setText("")
        refreshTemplatesList()
        Toast.makeText(this, "قالب اضافه شد ✅", Toast.LENGTH_SHORT).show()
    }

    /** لیست قالب‌های ذخیره‌شده را به‌صورت ردیف‌هایی با دکمه حذف نمایش می‌دهد. */
    private fun refreshTemplatesList() {
        val container = binding.templatesContainer
        container.removeAllViews()
        val templates = Prefs.getTemplates(this)

        if (templates.isEmpty()) {
            val empty = android.widget.TextView(this).apply {
                text = "هنوز قالبی ثبت نشده."
                textSize = 13f
                setTextColor(0xFF999999.toInt())
            }
            container.addView(empty)
            return
        }

        templates.forEachIndexed { index, template ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, 12, 0, 12)
            }

            val label = android.widget.TextView(this).apply {
                text = "${index + 1}. $template"
                textSize = 13f
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
            }

            val deleteBtn = android.widget.Button(this).apply {
                text = "حذف"
                textSize = 12f
                setOnClickListener {
                    Prefs.removeTemplate(this@MainActivity, index)
                    refreshTemplatesList()
                }
            }

            row.addView(label)
            row.addView(deleteBtn)
            container.addView(row)
        }
    }

    /** متن تستی وارد‌شده را با قالب‌های ذخیره‌شده مقایسه می‌کند و نتیجه را نمایش می‌دهد. */
    private fun testTemplateMatch() {
        val sample = binding.editTestSms.text.toString()
        if (sample.isBlank()) {
            Toast.makeText(this, "یه نمونه پیامک برای تست وارد کن", Toast.LENGTH_SHORT).show()
            return
        }

        val templates = Prefs.getTemplates(this)
        if (templates.isEmpty()) {
            binding.textTestResult.text = "⚠️ هنوز هیچ قالبی ثبت نشده."
            return
        }

        val match = TemplateMatcher.findMatch(sample, templates)
        binding.textTestResult.text = if (match == null) {
            "❌ با هیچ‌کدام از قالب‌ها مطابقت نداشت."
        } else {
            val groupsText = if (match.groups.isEmpty()) {
                "(بدون فیلد متغیر)"
            } else {
                match.groups.entries.joinToString(" | ") { "${it.key}=${it.value}" }
            }
            "✅ با قالب شماره ${match.templateIndex + 1} مطابقت داشت.\n$groupsText"
        }
    }
}
