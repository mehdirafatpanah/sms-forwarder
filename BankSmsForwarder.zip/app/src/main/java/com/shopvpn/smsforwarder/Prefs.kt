package com.shopvpn.smsforwarder

import android.content.Context
import android.content.SharedPreferences

/**
 * نگهداری تنظیمات کاربر: آدرس وب‌هوک، توکن امنیتی و لیست شماره فرستنده‌های مجاز بانک‌ها.
 * از EncryptedSharedPreferences استفاده نشده تا وابستگی اضافه نداشته باشیم؛
 * چون توکن فقط برای همین یک دستگاه و به همراه HTTPS استفاده می‌شود.
 */
object Prefs {
    private const val FILE = "sms_forwarder_prefs"
    private const val KEY_WEBHOOK_URL = "webhook_url"
    private const val KEY_TOKEN = "webhook_token"
    private const val KEY_TEMPLATES = "sms_templates" // آرایه JSON از رشته‌های قالب
    private const val KEY_DEVICE_ID = "device_id"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getWebhookUrl(ctx: Context): String = sp(ctx).getString(KEY_WEBHOOK_URL, "") ?: ""
    fun setWebhookUrl(ctx: Context, value: String) = sp(ctx).edit().putString(KEY_WEBHOOK_URL, value).apply()

    fun getToken(ctx: Context): String = sp(ctx).getString(KEY_TOKEN, "") ?: ""
    fun setToken(ctx: Context, value: String) = sp(ctx).edit().putString(KEY_TOKEN, value).apply()

    /** لیست قالب‌های ذخیره‌شده توسط کاربر. */
    fun getTemplates(ctx: Context): List<String> {
        val raw = sp(ctx).getString(KEY_TEMPLATES, "[]") ?: "[]"
        return try {
            val arr = org.json.JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun setTemplates(ctx: Context, templates: List<String>) {
        val arr = org.json.JSONArray()
        templates.forEach { arr.put(it) }
        sp(ctx).edit().putString(KEY_TEMPLATES, arr.toString()).apply()
    }

    fun addTemplate(ctx: Context, template: String) {
        val list = getTemplates(ctx).toMutableList()
        list.add(template)
        setTemplates(ctx, list)
    }

    fun removeTemplate(ctx: Context, index: Int) {
        val list = getTemplates(ctx).toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            setTemplates(ctx, list)
        }
    }

    fun getDeviceId(ctx: Context): String {
        var id = sp(ctx).getString(KEY_DEVICE_ID, null)
        if (id == null) {
            id = "device-" + System.currentTimeMillis().toString(36)
            sp(ctx).edit().putString(KEY_DEVICE_ID, id).apply()
        }
        return id
    }

    fun isConfigured(ctx: Context): Boolean =
        getWebhookUrl(ctx).isNotBlank() && getToken(ctx).isNotBlank()
}
