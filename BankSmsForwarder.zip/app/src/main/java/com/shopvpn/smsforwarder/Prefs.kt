package com.shopvpn.smsforwarder

import android.content.Context
import android.content.SharedPreferences

/**
 * نگهداری تنظیمات کاربر: آدرس وب‌هوک، توکن امنیتی و لیست شماره فرستنده‌های مجاز بانک‌ها.
 * از EncryptedSharedPreferences استفاده نشده تا وابستگی اضافه نداشته باشیم؛
 * چون توکن فقط برای همین یک دستگاه و به همراه HTTPS استفاده می‌شود.
 */
object Prefs {
    private const val FILE = "sms_forwarder_prefs"
    private const val KEY_WEBHOOK_URL = "webhook_url"
    private const val KEY_TOKEN = "webhook_token"
    private const val KEY_SENDERS = "allowed_senders" // با کاما جدا شده، خالی = همه پیامک‌ها فوروارد شود
    private const val KEY_DEVICE_ID = "device_id"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getWebhookUrl(ctx: Context): String = sp(ctx).getString(KEY_WEBHOOK_URL, "") ?: ""
    fun setWebhookUrl(ctx: Context, value: String) = sp(ctx).edit().putString(KEY_WEBHOOK_URL, value).apply()

    fun getToken(ctx: Context): String = sp(ctx).getString(KEY_TOKEN, "") ?: ""
    fun setToken(ctx: Context, value: String) = sp(ctx).edit().putString(KEY_TOKEN, value).apply()

    fun getAllowedSendersRaw(ctx: Context): String = sp(ctx).getString(KEY_SENDERS, "") ?: ""
    fun setAllowedSendersRaw(ctx: Context, value: String) = sp(ctx).edit().putString(KEY_SENDERS, value).apply()

    /** لیست شماره‌های مجاز (trim شده)؛ اگر خالی باشد یعنی همه پیامک‌ها فوروارد می‌شوند. */
    fun getAllowedSenders(ctx: Context): List<String> =
        getAllowedSendersRaw(ctx).split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

    fun getDeviceId(ctx: Context): String {
        var id = sp(ctx).getString(KEY_DEVICE_ID, null)
        if (id == null) {
            id = "device-" + System.currentTimeMillis().toString(36)
            sp(ctx).edit().putString(KEY_DEVICE_ID, id).apply()
        }
        return id
    }

    fun isConfigured(ctx: Context): Boolean =
        getWebhookUrl(ctx).isNotBlank() && getToken(ctx).isNotBlank()
}
