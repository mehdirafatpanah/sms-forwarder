package com.shopvpn.smsforwarder

/**
 * قالب‌های پیش‌فرض پیامک بانک‌ها.
 *
 * این قالب‌ها از روی نمونه‌ی واقعی هر بانک که در تنظیمات همان بانک
 * («نمونه قالب X») نمایش داده می‌شود استخراج شده‌اند، تا کاربر مجبور
 * نباشد آن‌ها را دستی وارد کند. کاربر همچنان می‌تواند:
 *  - هرکدام از این قالب‌های پیش‌فرض را حذف کند،
 *  - و/یا قالب سفارشی خودش را (تکی یا گروهی) اضافه کند.
 *
 */
object DefaultBankTemplates {

    data class BankTemplate(val bankName: String, val template: String)

    val ALL: List<BankTemplate> = listOf(
        BankTemplate(
            "بلو",
            "بلو\nواریز به حساب\n+{amount}\nموجودی: {balance}\n{date} {time}"
        ),
        BankTemplate(
            "رسالت",
            "قرض الحسنه رسالت\nواریز {amount}\nمانده {balance}\n{date}"
        ),
        BankTemplate(
            "گردشگری",
            "گردشگری\nحساب {account}\nواریز +{amount}\nمانده: {balance}\n{time}"
        ),
        BankTemplate(
            "سینا",
            "سینا\nواریز مبلغ {amount} ریال\nموجودی {balance}"
        ),
        BankTemplate(
            "شهر",
            "بانک شهر\nواریز {amount} به حساب {account}\nموجودی {balance}"
        ),
        BankTemplate(
            "کارآفرین",
            "کارآفرین\nواریز {amount}\nمانده {balance}\n{date} {time}"
        ),
        BankTemplate(
            "آینده",
            "آینده\n+{amount}\nواریز حساب {account}\nمانده {balance}\n{time}"
        ),
        BankTemplate(
            "مهر ایران",
            "بانک\nواریز {amount}\nمانده {balance}\n{date}-{time}"
        ),
        BankTemplate(
            "رفاه",
            "رفاه\nمبلغ واریز: {amount}\nمانده: {balance}\n{date}-{time}"
        ),
        BankTemplate(
            "سامان",
            "سامان\n+{amount} واریز\nمانده: {balance}\n{date} {time}"
        ),
        BankTemplate(
            "پاسارگاد",
            "بانک پاسارگاد\nواریز به سپرده: {amount}\nموجودی: {balance}"
        ),
        BankTemplate(
            "سپه",
            "بانک سپه\nحساب شما به مبلغ {amount} بستانکار شد\nمانده {balance}"
        ),
        BankTemplate(
            "مسکن",
            "مسکن\nواریز: {amount}\nحساب {account}\nموجودی: {balance}\n{date}"
        ),
        BankTemplate(
            "ملی",
            "بانک ملی\nواریز:{amount}\nحساب:{account}\nمانده:{balance}\n{date}"
        ),
        BankTemplate(
            "کشاورزی",
            "بانک کشاورزی\nبه حساب شما {amount} واریز گردید\nمانده {balance}"
        ),
        BankTemplate(
            "صادرات",
            "بانک صادرات\nمبلغ {amount} به حساب شما واریز شد\nمانده {balance}\n{time}"
        ),
        BankTemplate(
            "اقتصاد نوین",
            "اقتصاد نوین\nواریز به حساب: {amount}\nموجودی: {balance}\n{date}-{time}"
        ),
        BankTemplate(
            "پارسیان",
            "{account}\nمبلغ:{amount}+\nمانده:{balance}\n{date}\n{time}"
        ),
        BankTemplate(
            "تجارت",
            "تجارت\nواریز مبلغ {amount}\nشماره حساب *{account}\nموجودی {balance}"
        ),
        BankTemplate(
            "ملت",
            "بانک ملت\nحساب {account}\nواریز {amount}\nمانده {balance}\n{date}-{time}"
        )
    )

    /** فقط رشته‌های قالب (بدون نام بانک) برای ذخیره در Prefs. */
    val templateStrings: List<String> get() = ALL.map { it.template }
}
