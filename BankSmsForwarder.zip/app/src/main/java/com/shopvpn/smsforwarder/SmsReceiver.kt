package com.shopvpn.smsforwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.work.BackoffPolicy
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * این receiver با اولویت بالا هر پیامک ورودی را می‌گیرد.
 * اگر متن پیامک با یکی از قالب‌های ذخیره‌شده توسط کاربر مطابقت داشته باشد
 * (نه بر اساس شماره فرستنده)، برای ارسال به وب‌هوک به WorkManager سپرده می‌شود.
 *
 * توجه: این کار داخل onReceive باید سریع انجام شود (بدون I/O سنگین)،
 * به همین دلیل کار واقعی شبکه به ForwardWorker واگذار شده است.
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (messages.isEmpty()) return

        // چند بخش یک پیامک طولانی ممکن است جدا برسند؛ اینجا با هم ترکیب می‌شوند.
        val sender = messages[0].originatingAddress ?: "unknown"
        val fullBody = messages.joinToString(separator = "") { it.messageBody ?: "" }
        val timestamp = messages[0].timestampMillis

        val templates = Prefs.getTemplates(context)
        if (templates.isEmpty()) {
            LogStore.add(context, sender, fullBody, "⚠️ هیچ قالبی ثبت نشده، پیامک نادیده گرفته شد")
            return
        }

        val match = TemplateMatcher.findMatch(fullBody, templates)
        if (match == null) {
            // پیامک با هیچ‌کدام از قالب‌های ذخیره‌شده مطابقت نداشت (احتمالاً بانکی نیست یا تبلیغاتی است)
            return
        }

        if (!Prefs.isConfigured(context)) {
            LogStore.add(context, sender, fullBody, "⚠️ قالب مطابقت داشت ولی اپ هنوز تنظیم نشده")
            return
        }

        val inputData = Data.Builder()
            .putString(ForwardWorker.KEY_SENDER, sender)
            .putString(ForwardWorker.KEY_BODY, fullBody)
            .putLong(ForwardWorker.KEY_TIMESTAMP, timestamp)
            .putInt(ForwardWorker.KEY_TEMPLATE_INDEX, match.templateIndex)
            .putString(ForwardWorker.KEY_MATCHED_AMOUNT, match.groups["amount"])
            .build()

        val request = OneTimeWorkRequestBuilder<ForwardWorker>()
            .setInputData(inputData)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(context).enqueue(request)
    }
}
