package com.shopvpn.smsforwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.work.BackoffPolicy
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * این receiver با اولویت بالا هر پیامک ورودی را می‌گیرد.
 * اگر شماره فرستنده در لیست سفید بانک‌ها باشد (یا لیست خالی باشد)،
 * متن پیامک را برای ارسال به وب‌هوک به WorkManager می‌سپارد.
 *
 * توجه: این کار داخل onReceive باید سریع انجام شود (بدون I/O سنگین)،
 * به همین دلیل کار واقعی شبکه به ForwardWorker واگذار شده است.
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (messages.isEmpty()) return

        // چند بخش یک پیامک طولانی ممکن است جدا برسند؛ اینجا با هم ترکیب می‌شوند.
        val sender = messages[0].originatingAddress ?: "unknown"
        val fullBody = messages.joinToString(separator = "") { it.messageBody ?: "" }
        val timestamp = messages[0].timestampMillis

        val allowed = Prefs.getAllowedSenders(context)
        val isAllowed = allowed.isEmpty() || allowed.any { sender.contains(it) }

        if (!isAllowed) {
            return // پیامک‌های غیربانکی (تبلیغات، کد یکبار مصرف شخصی و ...) نادیده گرفته می‌شوند
        }

        if (!Prefs.isConfigured(context)) {
            LogStore.add(context, sender, fullBody, "⚠️ دریافت شد ولی اپ هنوز تنظیم نشده")
            return
        }

        val inputData = Data.Builder()
            .putString(ForwardWorker.KEY_SENDER, sender)
            .putString(ForwardWorker.KEY_BODY, fullBody)
            .putLong(ForwardWorker.KEY_TIMESTAMP, timestamp)
            .build()

        val request = OneTimeWorkRequestBuilder<ForwardWorker>()
            .setInputData(inputData)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(context).enqueue(request)
    }
}
