package com.shopvpn.smsforwarder

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * این Worker یک پیامک را به وب‌هوک سرور ارسال می‌کند.
 * WorkManager به‌صورت خودکار retry با backoff نمایی انجام می‌دهد اگر شبکه در دسترس نباشد
 * یا سرور خطای موقت برگرداند (این تنظیم هنگام enqueue کردن Work مشخص می‌شود).
 */
class ForwardWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    companion object {
        const val KEY_SENDER = "sender"
        const val KEY_BODY = "body"
        const val KEY_TIMESTAMP = "timestamp"

        private val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()

        private val JSON = "application/json; charset=utf-8".toMediaType()
    }

    override suspend fun doWork(): Result {
        val sender = inputData.getString(KEY_SENDER) ?: return Result.failure()
        val body = inputData.getString(KEY_BODY) ?: return Result.failure()
        val timestamp = inputData.getLong(KEY_TIMESTAMP, System.currentTimeMillis())

        val webhookUrl = Prefs.getWebhookUrl(applicationContext)
        val token = Prefs.getToken(applicationContext)

        if (webhookUrl.isBlank() || token.isBlank()) {
            LogStore.add(applicationContext, sender, body, "❌ تنظیمات کامل نیست (آدرس یا توکن خالی)")
            return Result.failure()
        }

        val payload = JSONObject().apply {
            put("sender", sender)
            put("body", body)
            put("received_at", timestamp)
            put("device_id", Prefs.getDeviceId(applicationContext))
        }

        val request = Request.Builder()
            .url(webhookUrl)
            .addHeader("X-Webhook-Token", token)
            .post(payload.toString().toRequestBody(JSON))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    LogStore.add(applicationContext, sender, body, "✅ ارسال موفق (HTTP ${response.code})")
                    Result.success()
                } else if (response.code in 500..599) {
                    // خطای موقت سرور -> تلاش مجدد
                    LogStore.add(applicationContext, sender, body, "⏳ خطای سرور (HTTP ${response.code})، تلاش مجدد...")
                    Result.retry()
                } else {
                    // خطای دائمی مثل 401/400 -> دیگر تلاش نکن
                    LogStore.add(applicationContext, sender, body, "❌ رد شد توسط سرور (HTTP ${response.code})")
                    Result.failure()
                }
            }
        } catch (e: Exception) {
            LogStore.add(applicationContext, sender, body, "⏳ خطای شبکه (${e.message})، تلاش مجدد...")
            Result.retry()
        }
    }
}
