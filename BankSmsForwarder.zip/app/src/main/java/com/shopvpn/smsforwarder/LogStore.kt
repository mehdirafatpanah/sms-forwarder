package com.shopvpn.smsforwarder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * یک لاگ ساده و سبک از آخرین پیامک‌های پردازش‌شده، صرفاً برای نمایش وضعیت داخل اپ.
 * حداکثر MAX_ITEMS مورد آخر نگه داشته می‌شود.
 */
object LogStore {
    private const val FILE = "sms_forwarder_log"
    private const val KEY_ITEMS = "items"
    private const val MAX_ITEMS = 50

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun add(context: Context, sender: String, bodyPreview: String, status: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString(KEY_ITEMS, "[]"))

        val entry = JSONObject().apply {
            put("time", dateFormat.format(Date()))
            put("sender", sender)
            put("preview", bodyPreview.take(60))
            put("status", status)
        }

        val newArr = JSONArray()
        newArr.put(entry)
        // آخرین مورد اول نمایش داده شود، و از قدیمی‌ترها فقط MAX_ITEMS-1 مورد نگه داشته شود
        for (i in 0 until minOf(arr.length(), MAX_ITEMS - 1)) {
            newArr.put(arr.get(i))
        }

        sp.edit().putString(KEY_ITEMS, newArr.toString()).apply()
    }

    fun getAllAsText(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString(KEY_ITEMS, "[]"))
        if (arr.length() == 0) return "هنوز پیامکی پردازش نشده است."

        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            sb.append("[${o.getString("time")}] ${o.getString("status")}\n")
            sb.append("از: ${o.getString("sender")}\n")
            sb.append("متن: ${o.getString("preview")}\n")
            sb.append("——————————\n")
        }
        return sb.toString()
    }
}
