package com.shopvpn.smsforwarder

import android.animation.ValueAnimator
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

/**
 * مجموعه‌ی کوچکی از انیمیشن‌های قابل‌استفاده‌ی مجدد برای زنده‌کردن UI:
 * فشردن دکمه‌ها، ورود مرحله‌ای کارت‌ها، ضربان (pulse) روی تغییر وضعیت
 * و یک انیمیشن جشن کوچک برای اکشن‌های موفق.
 * هیچ‌کدام به کتابخانه یا فایل انیمیشن خارجی نیاز ندارند (فقط API استاندارد اندروید).
 */
object AnimUtils {

    /** با لمس هر View (دکمه، کارت و ...) کمی جمع می‌شود و با رهاکردن با حالت فنری برمی‌گردد. */
    fun pressScale(view: View, downScale: Float = 0.96f) {
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().scaleX(downScale).scaleY(downScale)
                        .setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f)
                        .setDuration(220).setInterpolator(OvershootInterpolator(2.2f)).start()
                }
            }
            false // اجازه می‌دهد کلیک/ریپل عادی هم اجرا شود
        }
    }

    /**
     * کارت‌ها/چیپ‌ها را به‌ترتیب و با تاخیر کوتاه از پایین محو-ظاهر می‌کند؛
     * حس ورود پویا و حرفه‌ای به صفحه می‌دهد. فقط باید یک‌بار (در onCreate) صدا زده شود.
     */
    fun staggerReveal(views: List<View>, baseDelayMs: Long = 70L, startOffsetMs: Long = 60L) {
        views.forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 44f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(startOffsetMs + index * baseDelayMs)
                .setDuration(380)
                .setInterpolator(DecelerateInterpolator(1.4f))
                .start()
        }
    }

    /** ضربان کوتاه (بزرگ‌شدن و برگشت) — برای تاکید روی تغییر وضعیت یک چیپ/آیکون. */
    fun pulse(view: View) {
        view.animate().cancel()
        view.scaleX = 1f
        view.scaleY = 1f
        view.animate()
            .scaleX(1.14f).scaleY(1.14f)
            .setDuration(140)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                view.animate().scaleX(1f).scaleY(1f)
                    .setDuration(180)
                    .setInterpolator(OvershootInterpolator(3f))
                    .start()
            }.start()
    }

    /** یک جشن کوچک برای اکشن موفق (مثل ارسال موفق پیام تست): چرخش و بزرگ‌نمایی فنری. */
    fun celebrate(view: View) {
        view.animate().cancel()
        view.rotation = 0f
        view.animate()
            .scaleX(1.3f).scaleY(1.3f)
            .rotationBy(360f)
            .setDuration(480)
            .setInterpolator(OvershootInterpolator(2.5f))
            .withEndAction {
                view.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }.start()
    }

    /**
     * یک نبض ملایم و بی‌پایان روی یک View (مثلاً یک لایه‌ی نورانی روی هدر گرادیانی)
     * تا صفحه حس «زنده و پویا» بدهد، بدون این‌که مزاحم خواندن محتوا شود.
     */
    fun startAmbientGlow(view: View): ValueAnimator {
        val animator = ValueAnimator.ofFloat(0.12f, 0.30f).apply {
            duration = 2200
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { view.alpha = it.animatedValue as Float }
        }
        animator.start()
        return animator
    }
}
