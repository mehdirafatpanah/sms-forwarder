package com.shopvpn.smsforwarder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.shopvpn.smsforwarder.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS
    )

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            Toast.makeText(this, "مجوزها با موفقیت داده شد ✅", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "بدون این مجوزها اپ نمی‌تواند پیامک بخواند ❌", Toast.LENGTH_LONG).show()
        }
        updatePermissionStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // بارگذاری تنظیمات ذخیره‌شده
        binding.editWebhookUrl.setText(Prefs.getWebhookUrl(this))
        binding.editToken.setText(Prefs.getToken(this))

        binding.btnRequestPermissions.setOnClickListener { requestSmsPermissions() }
        binding.btnBatteryOptimization.setOnClickListener { requestIgnoreBatteryOptimizations() }

        binding.btnSave.setOnClickListener {
            Prefs.setWebhookUrl(this, binding.editWebhookUrl.text.toString().trim())
            Prefs.setToken(this, binding.editToken.text.toString().trim())
            Toast.makeText(this, "تنظیمات ذخیره شد ✅", Toast.LENGTH_SHORT).show()
        }

        binding.btnTestConnection.setOnClickListener { sendTestPing() }
        binding.btnRefreshLog.setOnClickListener { refreshLog() }

        binding.btnOpenTemplateSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // در اولین اجرای برنامه، قالب‌های پیش‌فرض بانک‌ها را به‌صورت خودکار اضافه می‌کند.
        Prefs.ensureDefaultTemplatesLoaded(this)

        updatePermissionStatus()
        updateBatteryStatus()
        refreshLog()
        updateTemplatesSummary()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
        updateBatteryStatus()
        refreshLog()
        updateTemplatesSummary()
    }

    /** تعداد قالب‌های ذخیره‌شده را روی کارت میان‌بر «مدیریت قالب‌های بانکی» نشان می‌دهد. */
    private fun updateTemplatesSummary() {
        val count = Prefs.getTemplateEntries(this).size
        binding.textTemplatesSummary.text = "قالب‌های پیامک بانک ($count قالب)"
    }

    private fun hasAllPermissions(): Boolean =
        requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestSmsPermissions() {
        if (!hasAllPermissions()) {
            permissionLauncher.launch(requiredPermissions)
        } else {
            Toast.makeText(this, "مجوزها از قبل فعال هستند ✅", Toast.LENGTH_SHORT).show()
        }
    }

    /** چیپ وضعیت مجوز پیامک را متناسب با وضعیت فعلی (سبز/قرمز) رنگ‌آمیزی می‌کند. */
    private fun updatePermissionStatus() {
        val granted = hasAllPermissions()
        binding.textPermissionStatus.text = if (granted) "مجوز پیامک: فعال" else "مجوز پیامک: غیرفعال"

        val textColor = ContextCompat.getColor(this, if (granted) R.color.status_success else R.color.status_danger)
        binding.textPermissionStatus.setTextColor(textColor)
        binding.iconPermissionChip.setColorFilter(textColor)
        binding.iconPermissionChip.setImageResource(if (granted) R.drawable.ic_check else R.drawable.ic_close)
        binding.chipPermission.setBackgroundResource(
            if (granted) R.drawable.bg_chip_success else R.drawable.bg_chip_danger
        )
    }

    /** چیپ وضعیت معافیت از بهینه‌سازی باتری را متناسب با وضعیت فعلی رنگ‌آمیزی می‌کند. */
    private fun updateBatteryStatus() {
        val exempt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        } else {
            true
        }
        binding.textBatteryStatus.text = if (exempt) "باتری: بهینه" else "باتری: نیاز به تنظیم"

        val textColor = ContextCompat.getColor(this, if (exempt) R.color.status_success else R.color.status_warning)
        binding.textBatteryStatus.setTextColor(textColor)
        binding.iconBatteryChip.setColorFilter(textColor)
        binding.chipBattery.setBackgroundResource(
            if (exempt) R.drawable.bg_chip_success else R.drawable.bg_chip_warning
        )
    }

    /**
     * اندروید برای صرفه‌جویی باتری ممکن است اپ‌های در پس‌زمینه را محدود کند.
     * از کاربر می‌خواهیم این اپ را از Doze/App Standby معاف کند تا دریافت پیامک قطع نشود.
     */
    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "لطفاً دستی از تنظیمات گوشی، بهینه‌سازی باتری این اپ را خاموش کن", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "این اپ از قبل از بهینه‌سازی باتری معاف است ✅", Toast.LENGTH_SHORT).show()
        }
        updateBatteryStatus()
    }

    /** یک پیام آزمایشی به وب‌هوک می‌فرستد تا از صحت آدرس/توکن مطمئن شویم. */
    private fun sendTestPing() {
        val url = binding.editWebhookUrl.text.toString().trim()
        val token = binding.editToken.text.toString().trim()
        if (url.isBlank() || token.isBlank()) {
            Toast.makeText(this, "اول آدرس و توکن را وارد و ذخیره کن", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.setWebhookUrl(this, url)
        Prefs.setToken(this, token)

        val inputData = Data.Builder()
            .putString(ForwardWorker.KEY_SENDER, "TEST")
            .putString(ForwardWorker.KEY_BODY, "این یک پیام آزمایشی از اپ فورواردر است.")
            .putLong(ForwardWorker.KEY_TIMESTAMP, System.currentTimeMillis())
            .build()

        val request = OneTimeWorkRequestBuilder<ForwardWorker>()
            .setInputData(inputData)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(this).enqueue(request)
        Toast.makeText(this, "پیام تست ارسال شد؛ نتیجه را در بخش لاگ پایین صفحه ببین", Toast.LENGTH_LONG).show()

        binding.root.postDelayed({ refreshLog() }, 3000)
    }

    private fun refreshLog() {
        binding.textLog.text = LogStore.getAllAsText(this)
    }
}
