package com.shopvpn.smsforwarder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.widget.ImageView

/**
 * یک Drawable ساده: دایره‌ی رنگی + حرف اول نام روی آن (سفید، بولد، وسط‌چین).
 * دقیقاً همان الگویی که اپ‌های بانکی/پرداخت حرفه‌ای برای بانک‌هایی که هنوز
 * لوگوی گرافیکی‌شان اضافه نشده استفاده می‌کنند.
 */
class InitialsAvatarDrawable(
    private val letter: String,
    backgroundColorHex: String
) : Drawable() {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = try {
            Color.parseColor(backgroundColorHex)
        } catch (e: Exception) {
            Color.parseColor("#4F6BFF")
        }
        style = Paint.Style.FILL
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val radius = minOf(b.width(), b.height()) / 2f
        canvas.drawCircle(b.exactCenterX(), b.exactCenterY(), radius, bgPaint)

        textPaint.textSize = radius * 0.95f
        val fm = textPaint.fontMetrics
        val textY = b.exactCenterY() - (fm.ascent + fm.descent) / 2f
        canvas.drawText(letter, b.exactCenterX(), textY, textPaint)
    }

    override fun setAlpha(alpha: Int) {
        bgPaint.alpha = alpha
        textPaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        bgPaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java", ReplaceWith("android.graphics.PixelFormat.TRANSLUCENT"))
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}

object IconUtils {

    private const val DEFAULT_COLOR = "#7C8BA0" // خاکستری-آبی برای قالب‌های سفارشی بدون بانک مشخص

    /**
     * روی [imageView] لوگوی بانک [displayName] را می‌گذارد.
     * اول دنبال فایل واقعی `ic_bank_<key>.png/svg` در res/drawable می‌گردد
     * (که کاربر بعداً از https://github.com/amastaneh/IranianBankLogos اضافه می‌کند)؛
     * اگر پیدا نشد، یک آواتار رنگی با حرف اول اسم بانک نمایش می‌دهد.
     */
    fun applyBankAvatar(context: Context, imageView: ImageView, displayName: String) {
        val brand = BankBrands.forName(displayName)
        val resId = brand?.let {
            context.resources.getIdentifier("ic_bank_${it.key}", "drawable", context.packageName)
        } ?: 0

        if (resId != 0) {
            imageView.imageTintList = null
            imageView.scaleType = ImageView.ScaleType.FIT_CENTER
            imageView.setPadding(0, 0, 0, 0)
            imageView.setImageResource(resId)
        } else {
            val letter = displayName.trim().firstOrNull()?.toString() ?: "؟"
            val color = brand?.color ?: DEFAULT_COLOR
            imageView.setImageDrawable(InitialsAvatarDrawable(letter, color))
        }
    }
}
