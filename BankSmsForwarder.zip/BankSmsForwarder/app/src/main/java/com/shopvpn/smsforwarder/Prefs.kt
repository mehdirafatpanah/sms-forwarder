package com.shopvpn.smsforwarder

import android.content.Context
import android.content.SharedPreferences

/**
 * نگهداری تنظیمات کاربر: آدرس وب‌هوک، توکن امنیتی و لیست قالب‌های پیامک بانک.
 * از EncryptedSharedPreferences استفاده نشده تا وابستگی اضافه نداشته باشیم؛
 * چون توکن فقط برای همین یک دستگاه و به همراه HTTPS استفاده می‌شود.
 */
object Prefs {

    /** یک قالب ذخیره‌شده به همراه نام قابل‌نمایش (مثلاً نام بانک). */
    data class TemplateEntry(val name: String, val template: String)

    private const val FILE = "sms_forwarder_prefs"
    private const val KEY_WEBHOOK_URL = "webhook_url"
    private const val KEY_TOKEN = "webhook_token"
    private const val KEY_TEMPLATES = "sms_templates" // آرایه JSON از {"name":.., "template":..}
    private const val KEY_DEVICE_ID = "device_id"
    private const val KEY_DEFAULTS_LOADED = "default_templates_loaded"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getWebhookUrl(ctx: Context): String = sp(ctx).getString(KEY_WEBHOOK_URL, "") ?: ""
    fun setWebhookUrl(ctx: Context, value: String) = sp(ctx).edit().putString(KEY_WEBHOOK_URL, value).apply()

    fun getToken(ctx: Context): String = sp(ctx).getString(KEY_TOKEN, "") ?: ""
    fun setToken(ctx: Context, value: String) = sp(ctx).edit().putString(KEY_TOKEN, value).apply()

    /** نامی مناسب برای نمایش، وقتی کاربر یا قالب پیش‌فرض اسم مشخصی ندارد. */
    private fun fallbackName(template: String, index: Int): String {
        val firstLine = template.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
        // اگر خط اول خودش یک placeholder باشد (مثل «{account}»)، نام‌گذاری خودکار قابل‌فهم نیست.
        val isPlaceholderOnly = Regex("^\\{\\w+\\}$").matches(firstLine)
        return if (firstLine.isNotEmpty() && !isPlaceholderOnly) firstLine else "قالب سفارشی #${index + 1}"
    }

    /**
     * لیست قالب‌های ذخیره‌شده (نام + متن قالب).
     * فرمت قدیمی (آرایه‌ی ساده‌ی رشته‌ها، بدون نام) به‌صورت خودکار به فرمت جدید مهاجرت می‌کند.
     */
    fun getTemplateEntries(ctx: Context): List<TemplateEntry> {
        val raw = sp(ctx).getString(KEY_TEMPLATES, "[]") ?: "[]"
        val entries = try {
            val arr = org.json.JSONArray(raw)
            (0 until arr.length()).map { i ->
                val el = arr.get(i)
                if (el is org.json.JSONObject) {
                    TemplateEntry(
                        name = el.optString("name").ifBlank { fallbackName(el.optString("template"), i) },
                        template = el.optString("template")
                    )
                } else {
                    // فرمت قدیمی: خود رشته، بدون نام جدا
                    val tpl = el.toString()
                    TemplateEntry(name = fallbackName(tpl, i), template = tpl)
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
        return entries
    }

    /** فقط متن قالب‌ها (برای TemplateMatcher). */
    fun getTemplates(ctx: Context): List<String> = getTemplateEntries(ctx).map { it.template }

    fun setTemplateEntries(ctx: Context, entries: List<TemplateEntry>) {
        val arr = org.json.JSONArray()
        entries.forEach { e ->
            val obj = org.json.JSONObject()
            obj.put("name", e.name)
            obj.put("template", e.template)
            arr.put(obj)
        }
        sp(ctx).edit().putString(KEY_TEMPLATES, arr.toString()).apply()
    }

    fun addTemplate(ctx: Context, template: String, name: String? = null) {
        val list = getTemplateEntries(ctx).toMutableList()
        list.add(TemplateEntry(name = name ?: fallbackName(template, list.size), template = template))
        setTemplateEntries(ctx, list)
    }

    /** ویرایش نام/متن یک قالب موجود بر اساس اندیس آن در لیست. */
    fun updateTemplateAt(ctx: Context, index: Int, name: String, template: String) {
        val list = getTemplateEntries(ctx).toMutableList()
        if (index in list.indices) {
            list[index] = TemplateEntry(name = name, template = template)
            setTemplateEntries(ctx, list)
        }
    }

    fun removeTemplate(ctx: Context, index: Int) {
        val list = getTemplateEntries(ctx).toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            setTemplateEntries(ctx, list)
        }
    }

    /**
     * فقط در اولین اجرای برنامه، تمام قالب‌های پیش‌فرض بانک‌ها را به لیست
     * قالب‌های کاربر اضافه می‌کند (بدون اینکه قالب‌های سفارشی موجود را پاک کند).
     * بعد از این، کاربر آزاد است هرکدام را حذف/ویرایش کند بدون اینکه دوباره برگردند.
     */
    fun ensureDefaultTemplatesLoaded(ctx: Context) {
        if (sp(ctx).getBoolean(KEY_DEFAULTS_LOADED, false)) return
        val existing = getTemplateEntries(ctx).toMutableList()
        val existingTemplates = existing.map { it.template }.toMutableSet()
        DefaultBankTemplates.ALL.forEach { bt ->
            if (existingTemplates.add(bt.template)) {
                existing.add(TemplateEntry(name = bt.bankName, template = bt.template))
            }
        }
        setTemplateEntries(ctx, existing)
        sp(ctx).edit().putBoolean(KEY_DEFAULTS_LOADED, true).apply()
    }

    /**
     * بازیابی دستی قالب‌های پیش‌فرض بانک‌ها (مثلاً اگر کاربر قبلاً حذفشان کرده بود).
     * فقط قالب‌هایی که هنوز در لیست نیستند اضافه می‌شوند؛ بازمی‌گرداند چند قالب اضافه شد.
     */
    fun restoreDefaultTemplates(ctx: Context): Int {
        val existing = getTemplateEntries(ctx).toMutableList()
        val existingTemplates = existing.map { it.template }.toMutableSet()
        var added = 0
        DefaultBankTemplates.ALL.forEach { bt ->
            if (existingTemplates.add(bt.template)) {
                existing.add(TemplateEntry(name = bt.bankName, template = bt.template))
                added++
            }
        }
        if (added > 0) setTemplateEntries(ctx, existing)
        sp(ctx).edit().putBoolean(KEY_DEFAULTS_LOADED, true).apply()
        return added
    }

    fun getDeviceId(ctx: Context): String {
        var id = sp(ctx).getString(KEY_DEVICE_ID, null)
        if (id == null) {
            id = "device-" + java.util.UUID.randomUUID().toString()
            sp(ctx).edit().putString(KEY_DEVICE_ID, id).apply()
        }
        return id
    }

    fun isConfigured(ctx: Context): Boolean =
        getWebhookUrl(ctx).isNotBlank() && getToken(ctx).isNotBlank()
}
