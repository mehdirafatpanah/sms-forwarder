package com.shopvpn.smsforwarder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * لیست قالب‌های ذخیره‌شده در صفحه‌ی تنظیمات؛ هر ردیف شامل لوگو/آواتار بانک،
 * نام، پیش‌نمایش کوتاه قالب و دو دکمه‌ی ویرایش/حذف است.
 */
class TemplateAdapter(
    private var entries: List<Prefs.TemplateEntry>,
    private val onEdit: (position: Int, entry: Prefs.TemplateEntry) -> Unit,
    private val onDelete: (position: Int, entry: Prefs.TemplateEntry) -> Unit
) : RecyclerView.Adapter<TemplateAdapter.TemplateViewHolder>() {

    class TemplateViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val logo: ImageView = view.findViewById(R.id.imgBankLogo)
        val name: TextView = view.findViewById(R.id.textTemplateName)
        val preview: TextView = view.findViewById(R.id.textTemplatePreview)
        val editBtn: ImageButton = view.findViewById(R.id.btnEditTemplate)
        val deleteBtn: ImageButton = view.findViewById(R.id.btnDeleteTemplate)
    }

    fun updateData(newEntries: List<Prefs.TemplateEntry>) {
        entries = newEntries
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TemplateViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_template, parent, false)
        return TemplateViewHolder(view)
    }

    override fun onBindViewHolder(holder: TemplateViewHolder, position: Int) {
        val entry = entries[position]
        holder.name.text = entry.name

        val lines = entry.template.lines().map { it.trim() }.filter { it.isNotEmpty() }
        holder.preview.text = if (lines.isNotEmpty()) lines.joinToString(" · ") else "قالب سفارشی"

        IconUtils.applyBankAvatar(holder.itemView.context, holder.logo, entry.name)

        holder.editBtn.setOnClickListener { onEdit(holder.bindingAdapterPosition, entry) }
        holder.deleteBtn.setOnClickListener { onDelete(holder.bindingAdapterPosition, entry) }
        AnimUtils.pressScale(holder.editBtn)
        AnimUtils.pressScale(holder.deleteBtn)
    }

    override fun getItemCount(): Int = entries.size
}
