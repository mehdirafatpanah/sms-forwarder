package com.shopvpn.smsforwarder

/**
 * اطلاعات نمایشی هر بانک: یک «کلید» یکتا (برای پیدا کردن فایل لوگو) و یک رنگ برند
 * (برای زمانی که هنوز فایل لوگوی واقعی آن بانک اضافه نشده — به‌جایش یک دایره‌ی
 * رنگی با حرف اول اسم بانک نمایش داده می‌شود، شبیه اپ‌های بانکی حرفه‌ای).
 *
 * نحوه‌ی افزودن لوگوی واقعی هر بانک:
 *   یک فایل PNG (مربعی، ترجیحاً پس‌زمینه شفاف) به نام `ic_bank_<key>.png` داخل
 *   `app/src/main/res/drawable-xxxhdpi/` قرار بده (حداقل سایز پیشنهادی 192x192).
 *   به محض وجود فایلی با این نام، اپ به‌صورت خودکار به‌جای دایره‌ی رنگی، همان
 *   لوگو را نمایش می‌دهد (نگاه کن به IconUtils.kt) — نیازی به تغییر کد نیست.
 *
 *   منبع پیشنهادی: https://github.com/masihgh/iranian-bank-list (لایسنس MIT،
 *   استفاده‌ی آزاد تجاری/غیرتجاری). فایل‌های آن‌جا SVG هستند؛ چون اندروید SVG خام
 *   را مستقیم نمایش نمی‌دهد، هرکدام را به PNG تبدیل کن (مثلاً با Vector Asset
 *   استودیوی اندروید یا هر مبدل آنلاین) و با همون اسم `key` پایین ذخیره کن —
 *   کلیدهای زیر عیناً با نام فایل‌های همان مخزن (`images/<key>.svg`) هماهنگ شده‌اند
 *   تا نیازی به تغییر اسم نباشد. منبع جایگزین: https://github.com/amastaneh/IranianBankLogos
 *
 *   رنگ‌ها هم از همون دیتاست (banks.json) گرفته شده؛ برای دو مورد (ملی، پاسارگاد)
 *   چون رنگ اصلی برند خیلی روشن است و متن سفید روی آن خوانا نیست، یک سایه‌ی
 *   تیره‌تر برای حالت «آواتار حرف اول» انتخاب شده (نه رنگ رسمی لوگو).
 */
data class BankBrand(val key: String, val color: String)

object BankBrands {

    /** نگاشت «نام بانک همان‌طور که در DefaultBankTemplates آمده» -> اطلاعات برند. */
    val BY_NAME: Map<String, BankBrand> = mapOf(
        "بلو" to BankBrand("blu", "#3094EA"),
        "رسالت" to BankBrand("resalat", "#0092CF"),
        "گردشگری" to BankBrand("gardeshgari", "#AF0A0F"),
        "سینا" to BankBrand("sina", "#16469C"),
        "شهر" to BankBrand("shahr", "#DD0000"),
        "کارآفرین" to BankBrand("karafarin", "#168474"),
        "آینده" to BankBrand("ayandeh", "#00A99D"), // در ادغام‌های اخیر ذیل «ملی» رفته؛ برای تمایز بصری جدا نگه داشته شده
        "مهر ایران" to BankBrand("mehriran", "#00A653"),
        "رفاه" to BankBrand("refahkargaran", "#1E7A00"),
        "سامان" to BankBrand("saman", "#00AAE8"),
        "پاسارگاد" to BankBrand("pasargad", "#B8860B"), // رنگ رسمی روشن‌تره (#FFC110)، این نسخه برای خوانایی متن سفید
        "سپه" to BankBrand("sepah", "#0093DD"),
        "مسکن" to BankBrand("maskan", "#FF0100"),
        "ملی" to BankBrand("melli", "#9C7A1E"), // رنگ رسمی روشن‌تره (#FFF689)، این نسخه برای خوانایی متن سفید
        "کشاورزی" to BankBrand("keshavarzi", "#112C09"),
        "صادرات" to BankBrand("saderat", "#29166F"),
        "اقتصاد نوین" to BankBrand("eghtesad", "#5C2E91"),
        "پارسیان" to BankBrand("parsian", "#A10F1F"),
        "تجارت" to BankBrand("tejarat", "#004C97"),
        "ملت" to BankBrand("mellat", "#D12236")
    )

    fun forName(bankName: String?): BankBrand? = BY_NAME[bankName]
}
