package com.shopvpn.smsforwarder

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.doOnPreDraw
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.transition.platform.MaterialContainerTransform
import com.shopvpn.smsforwarder.databinding.ActivitySettingsBinding
import com.shopvpn.smsforwarder.databinding.DialogEditTemplateBinding
import kotlin.math.abs

/**
 * صفحه‌ی جداگانه‌ی مدیریت قالب‌های پیامک بانک: افزودن تکی/گروهی، ویرایش،
 * حذف، بازیابی پیش‌فرض‌ها و تست تطبیق. قبلاً همه‌ی این‌ها داخل صفحه‌ی اصلی
 * بودند؛ برای تمیزتر شدن UI به این صفحه‌ی جدا منتقل شدند.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var adapter: TemplateAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // انیمیشن Container Transform: کارت «مدیریت قالب‌ها» در صفحه‌ی اصلی به این صفحه تبدیل می‌شود
        postponeEnterTransition()
        window.sharedElementEnterTransition = MaterialContainerTransform().apply {
            duration = 320L
            scrimColor = Color.TRANSPARENT
        }
        window.sharedElementReturnTransition = MaterialContainerTransform().apply {
            duration = 260L
            scrimColor = Color.TRANSPARENT
        }

        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.root.doOnPreDraw { startPostponedEnterTransition() }

        binding.btnBack.setOnClickListener { finishAfterTransition() }

        adapter = TemplateAdapter(
            entries = Prefs.getTemplateEntries(this),
            onEdit = { position, entry -> showEditDialog(position, entry) },
            onDelete = { position, _ -> deleteTemplate(position) }
        )
        binding.recyclerTemplates.layoutManager = LinearLayoutManager(this)
        binding.recyclerTemplates.adapter = adapter
        attachSwipeToDelete()

        binding.btnAddTemplate.setOnClickListener { addTemplate() }
        binding.btnBulkAddTemplates.setOnClickListener { bulkAddTemplates() }
        binding.btnTestTemplate.setOnClickListener { testTemplateMatch() }
        binding.btnRestoreDefaultTemplates.setOnClickListener { restoreDefaultTemplates() }

        listOf(
            binding.btnBack, binding.btnAddTemplate, binding.btnBulkAddTemplates,
            binding.btnTestTemplate, binding.btnRestoreDefaultTemplates
        ).forEach { AnimUtils.pressScale(it) }

        refreshTemplatesList()
    }

    /** پشتیبانی از بازگشت با دکمه‌ی سیستمی هم باید همان انیمیشن برگشت را اجرا کند. */
    override fun onBackPressed() {
        finishAfterTransition()
    }

    /**
     * کشیدن هر ردیف قالب به کنار، پس‌زمینه‌ی قرمز «حذف» را نشان می‌دهد؛ رهاکردن کامل
     * همان دیالوگ تاییدِ حذف قبلی را باز می‌کند (برای امنیت، حذف بدون تایید انجام نمی‌شود)
     * و اگر کاربر منصرف شود، ردیف بلافاصله به‌جای اولش برمی‌گردد.
     */
    private fun attachSwipeToDelete() {
        val deleteBg = ContextCompat.getColor(this, R.color.status_danger)
        val deleteIcon = ContextCompat.getDrawable(this, R.drawable.ic_delete)
            ?.mutate()?.apply { setTint(Color.WHITE) }?.toBitmap()
        val paint = Paint().apply { color = deleteBg; isAntiAlias = true }

        val callback = object : ItemTouchHelper.SimpleCallback(
            0, ItemTouchHelper.START or ItemTouchHelper.END
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ) = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.bindingAdapterPosition
                if (position == RecyclerView.NO_POSITION) return
                // بلافاصله ردیف را سرجایش برمی‌گردانیم؛ حذف واقعی فقط بعد از تایید در دیالوگ انجام می‌شود
                adapter.notifyItemChanged(position)
                deleteTemplate(position)
            }

            override fun onChildDraw(
                c: Canvas, recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder,
                dX: Float, dY: Float, actionState: Int, isCurrentlyActive: Boolean
            ) {
                val itemView = viewHolder.itemView
                val cornerRadius = 18f
                val rect = RectF(
                    itemView.left.toFloat(), itemView.top.toFloat(),
                    itemView.right.toFloat(), itemView.bottom.toFloat()
                )
                c.drawRoundRect(rect, cornerRadius, cornerRadius, paint)

                deleteIcon?.let { icon ->
                    val iconSize = 22 * itemView.resources.displayMetrics.density
                    val margin = (itemView.height - iconSize) / 2f
                    val top = itemView.top + margin
                    val iconRect = if (dX > 0) {
                        RectF(itemView.left + margin, top, itemView.left + margin + iconSize, top + iconSize)
                    } else {
                        RectF(itemView.right - margin - iconSize, top, itemView.right - margin, top + iconSize)
                    }
                    if (abs(dX) > iconSize) c.drawBitmap(icon, null, iconRect, paint)
                }

                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
            }
        }
        ItemTouchHelper(callback).attachToRecyclerView(binding.recyclerTemplates)
    }

    /** لیست را از Prefs دوباره می‌خواند و به آداپتور و شمارنده اعمال می‌کند. */
    private fun refreshTemplatesList() {
        val entries = Prefs.getTemplateEntries(this)
        adapter.updateData(entries)
        binding.textTemplatesCount.text = "قالب‌های ذخیره‌شده (${entries.size})"
        binding.textEmptyTemplates.visibility =
            if (entries.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        binding.recyclerTemplates.visibility =
            if (entries.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun addTemplate() {
        val name = binding.editNewTemplateName.text.toString().trim()
        val text = binding.editNewTemplate.text.toString().trim()
        if (text.isBlank()) {
            Toast.makeText(this, "متن قالب خالیه", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.addTemplate(this, text, name.ifBlank { null })
        binding.editNewTemplateName.setText("")
        binding.editNewTemplate.setText("")
        refreshTemplatesList()
        Toast.makeText(this, "قالب اضافه شد ✅", Toast.LENGTH_SHORT).show()
    }

    private fun bulkAddTemplates() {
        val raw = binding.editBulkTemplates.text.toString()
        if (raw.isBlank()) {
            Toast.makeText(this, "چیزی برای افزودن نیست", Toast.LENGTH_SHORT).show()
            return
        }

        val parts = raw.split(Regex("(?m)^\\s*---\\s*$"))
            .map { it.trim('\n', '\r', ' ') }
            .filter { it.isNotBlank() }

        if (parts.isEmpty()) {
            Toast.makeText(this, "هیچ قالب معتبری پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }

        val existing = Prefs.getTemplateEntries(this).toMutableList()
        parts.forEach { tpl ->
            existing.add(Prefs.TemplateEntry(name = "قالب سفارشی #${existing.size + 1}", template = tpl))
        }
        Prefs.setTemplateEntries(this, existing)
        binding.editBulkTemplates.setText("")
        refreshTemplatesList()
        Toast.makeText(this, "${parts.size} قالب اضافه شد ✅", Toast.LENGTH_LONG).show()
    }

    private fun restoreDefaultTemplates() {
        val added = Prefs.restoreDefaultTemplates(this)
        refreshTemplatesList()
        Toast.makeText(
            this,
            if (added > 0) "$added قالب پیش‌فرض اضافه شد ✅" else "همه قالب‌های پیش‌فرض از قبل موجودند",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun deleteTemplate(position: Int) {
        AlertDialog.Builder(this)
            .setTitle("حذف قالب")
            .setMessage("مطمئنی می‌خوای این قالب حذف بشه؟")
            .setPositiveButton("حذف") { _, _ ->
                Prefs.removeTemplate(this, position)
                refreshTemplatesList()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun showEditDialog(position: Int, entry: Prefs.TemplateEntry) {
        val dialogBinding = DialogEditTemplateBinding.inflate(LayoutInflater.from(this))
        dialogBinding.editDialogName.setText(entry.name)
        dialogBinding.editDialogTemplate.setText(entry.template)

        AlertDialog.Builder(this)
            .setTitle("ویرایش قالب")
            .setView(dialogBinding.root)
            .setPositiveButton("ذخیره") { _, _ ->
                val newName = dialogBinding.editDialogName.text.toString().trim()
                val newTemplate = dialogBinding.editDialogTemplate.text.toString().trim()
                if (newTemplate.isBlank()) {
                    Toast.makeText(this, "متن قالب نمی‌تواند خالی باشد", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                Prefs.updateTemplateAt(this, position, newName.ifBlank { entry.name }, newTemplate)
                refreshTemplatesList()
                Toast.makeText(this, "قالب به‌روزرسانی شد ✅", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun testTemplateMatch() {
        val sample = binding.editTestSms.text.toString()
        if (sample.isBlank()) {
            Toast.makeText(this, "یه نمونه پیامک برای تست وارد کن", Toast.LENGTH_SHORT).show()
            return
        }

        val templates = Prefs.getTemplates(this)
        if (templates.isEmpty()) {
            setTestResult("⚠️ هنوز هیچ قالبی ثبت نشده.", R.color.status_warning)
            return
        }

        val match = TemplateMatcher.findMatch(sample, templates)
        if (match == null) {
            setTestResult("❌ با هیچ‌کدام از قالب‌ها مطابقت نداشت.", R.color.status_danger)
        } else {
            val groupsText = if (match.groups.isEmpty()) {
                "(بدون فیلد متغیر)"
            } else {
                match.groups.entries.joinToString(" | ") { "${it.key}=${it.value}" }
            }
            setTestResult("✅ با قالب شماره ${match.templateIndex + 1} مطابقت داشت.\n$groupsText", R.color.status_success)
            AnimUtils.pulse(binding.textTestResult)
        }
    }

    private fun setTestResult(text: String, colorRes: Int) {
        binding.textTestResult.text = text
        binding.textTestResult.setTextColor(ContextCompat.getColor(this, colorRes))
    }
}
