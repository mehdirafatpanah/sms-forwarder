package com.shopvpn.smsforwarder

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.shopvpn.smsforwarder.databinding.ActivitySettingsBinding
import com.shopvpn.smsforwarder.databinding.DialogEditTemplateBinding

/**
 * صفحه‌ی جداگانه‌ی مدیریت قالب‌های پیامک بانک: افزودن تکی/گروهی، ویرایش،
 * حذف، بازیابی پیش‌فرض‌ها و تست تطبیق. قبلاً همه‌ی این‌ها داخل صفحه‌ی اصلی
 * بودند؛ برای تمیزتر شدن UI به این صفحه‌ی جدا منتقل شدند.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var adapter: TemplateAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }

        adapter = TemplateAdapter(
            entries = Prefs.getTemplateEntries(this),
            onEdit = { position, entry -> showEditDialog(position, entry) },
            onDelete = { position, _ -> deleteTemplate(position) }
        )
        binding.recyclerTemplates.layoutManager = LinearLayoutManager(this)
        binding.recyclerTemplates.adapter = adapter

        binding.btnAddTemplate.setOnClickListener { addTemplate() }
        binding.btnBulkAddTemplates.setOnClickListener { bulkAddTemplates() }
        binding.btnTestTemplate.setOnClickListener { testTemplateMatch() }
        binding.btnRestoreDefaultTemplates.setOnClickListener { restoreDefaultTemplates() }

        refreshTemplatesList()
    }

    /** لیست را از Prefs دوباره می‌خواند و به آداپتور و شمارنده اعمال می‌کند. */
    private fun refreshTemplatesList() {
        val entries = Prefs.getTemplateEntries(this)
        adapter.updateData(entries)
        binding.textTemplatesCount.text = "قالب‌های ذخیره‌شده (${entries.size})"
        binding.textEmptyTemplates.visibility =
            if (entries.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        binding.recyclerTemplates.visibility =
            if (entries.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun addTemplate() {
        val name = binding.editNewTemplateName.text.toString().trim()
        val text = binding.editNewTemplate.text.toString().trim()
        if (text.isBlank()) {
            Toast.makeText(this, "متن قالب خالیه", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.addTemplate(this, text, name.ifBlank { null })
        binding.editNewTemplateName.setText("")
        binding.editNewTemplate.setText("")
        refreshTemplatesList()
        Toast.makeText(this, "قالب اضافه شد ✅", Toast.LENGTH_SHORT).show()
    }

    private fun bulkAddTemplates() {
        val raw = binding.editBulkTemplates.text.toString()
        if (raw.isBlank()) {
            Toast.makeText(this, "چیزی برای افزودن نیست", Toast.LENGTH_SHORT).show()
            return
        }

        val parts = raw.split(Regex("(?m)^\\s*---\\s*$"))
            .map { it.trim('\n', '\r', ' ') }
            .filter { it.isNotBlank() }

        if (parts.isEmpty()) {
            Toast.makeText(this, "هیچ قالب معتبری پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }

        val existing = Prefs.getTemplateEntries(this).toMutableList()
        parts.forEach { tpl ->
            existing.add(Prefs.TemplateEntry(name = "قالب سفارشی #${existing.size + 1}", template = tpl))
        }
        Prefs.setTemplateEntries(this, existing)
        binding.editBulkTemplates.setText("")
        refreshTemplatesList()
        Toast.makeText(this, "${parts.size} قالب اضافه شد ✅", Toast.LENGTH_LONG).show()
    }

    private fun restoreDefaultTemplates() {
        val added = Prefs.restoreDefaultTemplates(this)
        refreshTemplatesList()
        Toast.makeText(
            this,
            if (added > 0) "$added قالب پیش‌فرض اضافه شد ✅" else "همه قالب‌های پیش‌فرض از قبل موجودند",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun deleteTemplate(position: Int) {
        AlertDialog.Builder(this)
            .setTitle("حذف قالب")
            .setMessage("مطمئنی می‌خوای این قالب حذف بشه؟")
            .setPositiveButton("حذف") { _, _ ->
                Prefs.removeTemplate(this, position)
                refreshTemplatesList()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun showEditDialog(position: Int, entry: Prefs.TemplateEntry) {
        val dialogBinding = DialogEditTemplateBinding.inflate(LayoutInflater.from(this))
        dialogBinding.editDialogName.setText(entry.name)
        dialogBinding.editDialogTemplate.setText(entry.template)

        AlertDialog.Builder(this)
            .setTitle("ویرایش قالب")
            .setView(dialogBinding.root)
            .setPositiveButton("ذخیره") { _, _ ->
                val newName = dialogBinding.editDialogName.text.toString().trim()
                val newTemplate = dialogBinding.editDialogTemplate.text.toString().trim()
                if (newTemplate.isBlank()) {
                    Toast.makeText(this, "متن قالب نمی‌تواند خالی باشد", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                Prefs.updateTemplateAt(this, position, newName.ifBlank { entry.name }, newTemplate)
                refreshTemplatesList()
                Toast.makeText(this, "قالب به‌روزرسانی شد ✅", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun testTemplateMatch() {
        val sample = binding.editTestSms.text.toString()
        if (sample.isBlank()) {
            Toast.makeText(this, "یه نمونه پیامک برای تست وارد کن", Toast.LENGTH_SHORT).show()
            return
        }

        val templates = Prefs.getTemplates(this)
        if (templates.isEmpty()) {
            setTestResult("⚠️ هنوز هیچ قالبی ثبت نشده.", R.color.status_warning)
            return
        }

        val match = TemplateMatcher.findMatch(sample, templates)
        if (match == null) {
            setTestResult("❌ با هیچ‌کدام از قالب‌ها مطابقت نداشت.", R.color.status_danger)
        } else {
            val groupsText = if (match.groups.isEmpty()) {
                "(بدون فیلد متغیر)"
            } else {
                match.groups.entries.joinToString(" | ") { "${it.key}=${it.value}" }
            }
            setTestResult("✅ با قالب شماره ${match.templateIndex + 1} مطابقت داشت.\n$groupsText", R.color.status_success)
        }
    }

    private fun setTestResult(text: String, colorRes: Int) {
        binding.textTestResult.text = text
        binding.textTestResult.setTextColor(ContextCompat.getColor(this, colorRes))
    }
}
