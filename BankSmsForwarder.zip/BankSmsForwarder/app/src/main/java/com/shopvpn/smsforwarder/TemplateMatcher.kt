package com.shopvpn.smsforwarder

/**
 * تبدیل یک «قالب پیامک» که کاربر با placeholder مثل {amount} نوشته
 * به یک Regex واقعی، و تطبیق پیامک‌های ورودی با لیست قالب‌های ذخیره‌شده.
 *
 * placeholder های پشتیبانی‌شده:
 *   {amount} / {balance} -> اعداد (فارسی یا انگلیسی) با جداکننده هزارگان
 *   {date}               -> تاریخ با اسلش یا خط تیره
 *   {time}                -> ساعت با دونقطه
 *   {tracking}/{account}/{card} -> کد/شماره (رقم یا حروف انگلیسی)
 *   هر اسم دیگری          -> هر متنی (غیرحریصانه)
 *
 * بقیه‌ی متن قالب (متن ثابت) عیناً باید در پیامک واقعی وجود داشته باشد؛
 * با این استثنا که هر فاصله‌ی سفید (space/خط‌جدید/تب) در قالب، با هر نوع و تعداد
 * فاصله‌ی سفید در پیامک واقعی مطابقت دارد (مثلاً بین تاریخ و ساعت، فرقی نمی‌کند
 * قالب را با space نوشته باشی یا خط جدید).
 */
object TemplateMatcher {

    data class Match(val templateIndex: Int, val groups: Map<String, String>)

    private val PLACEHOLDER_REGEX = Regex("\\{(\\w+)\\}")
    private val SPECIAL_CHARS = charArrayOf('\\', '.', '^', '$', '|', '?', '*', '+', '(', ')', '[', ']', '{', '}')

    private fun patternFor(name: String): String = when (name.lowercase()) {
        "amount", "balance" -> "([0-9\u06F0-\u06F9,\u066C]+)"
        "date" -> "([0-9\u06F0-\u06F9/\\-]+)"
        "time" -> "([0-9\u06F0-\u06F9:]+)"
        "tracking", "account", "card" -> "([0-9\u06F0-\u06F9A-Za-z\\-]+)"
        else -> "([\\s\\S]+?)"
    }

    private fun escapeLiteral(text: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c.isWhitespace()) {
                // هر رشته‌ی پشت‌سرهم از فاصله/خط‌جدید/تب در متن قالب، به «۱ یا چند فاصله‌ی
                // سفید از هر نوع» تفسیر می‌شود. این باعث می‌شود قالب چه بین دو بخش یک
                // space بگذارد چه \n، با پیامک واقعی (که ممکن است بسته به گوشی/اپراتور
                // این جداکننده‌ها را متفاوت بفرستد) مطابقت داشته باشد.
                while (i < text.length && text[i].isWhitespace()) i++
                sb.append("\\s+")
                continue
            }
            if (SPECIAL_CHARS.contains(c)) sb.append('\\')
            sb.append(c)
            i++
        }
        return sb.toString()
    }

    /** قالب متنی را به یک Regex قابل اجرا تبدیل می‌کند. */
    fun buildRegex(template: String): Regex {
        val sb = StringBuilder()
        var lastEnd = 0
        for (m in PLACEHOLDER_REGEX.findAll(template)) {
            sb.append(escapeLiteral(template.substring(lastEnd, m.range.first)))
            sb.append(patternFor(m.groupValues[1]))
            lastEnd = m.range.last + 1
        }
        sb.append(escapeLiteral(template.substring(lastEnd)))
        return Regex(sb.toString())
    }

    private fun placeholderNames(template: String): List<String> =
        PLACEHOLDER_REGEX.findAll(template).map { it.groupValues[1] }.toList()

    /** پیامک را با لیست قالب‌های ذخیره‌شده مقایسه می‌کند؛ اولین قالبی که مطابقت داشت برگردانده می‌شود. */
    fun findMatch(body: String, templates: List<String>): Match? {
        templates.forEachIndexed { index, template ->
            if (template.isBlank()) return@forEachIndexed
            try {
                val names = placeholderNames(template)
                val result = buildRegex(template).find(body) ?: return@forEachIndexed
                val groups = mutableMapOf<String, String>()
                names.forEachIndexed { gi, name ->
                    result.groupValues.getOrNull(gi + 1)?.let { groups[name] = it }
                }
                return Match(index, groups)
            } catch (e: Exception) {
                // قالب نامعتبر (regex خراب) -> نادیده گرفته می‌شود، سراغ قالب بعدی می‌رویم
            }
        }
        return null
    }
}
